// Run with: npm run seed
// Populates barbers, services, testimonials, inventory, customers & a couple of
// sample appointments into an empty database, and makes sure the Settings
// singleton exists. Safe to re-run — it skips collections that already have data.
require('dotenv').config({ quiet: true });
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const { connectDB } = require('./middleware/connectDB');

const Settings = require('./models/Settings');
const Barber = require('./models/Barber');
const Service = require('./models/Service');
const Testimonial = require('./models/Testimonial');
const InventoryItem = require('./models/InventoryItem');
const Appointment = require('./models/Appointment');
const Customer = require('./models/Customer');

const BARBERS = [
  { name: 'Peter Otieno', specialty: 'Classic Cuts & Fades', exp: 5, rating: 4.9, avatar: '💈', reviews: 87 },
  { name: 'James Kyalo', specialty: 'Modern & Textured Styles', exp: 5, rating: 4.8, avatar: '✂', reviews: 72 },
  { name: 'Onyango Paul', specialty: 'Beard Artistry', exp: 3, rating: 4.7, avatar: '🧔', reviews: 54 },
  { name: 'Martin Kelly', specialty: 'Hair Colouring Specialist', exp: 4, rating: 4.8, avatar: '🎨', reviews: 61 },
];

const SERVICES = [
  { name: 'Haircut', price: 1000, duration: '45 min', desc: 'Classic to modern cuts tailored to your style', icon: '✂' },
  { name: 'Beard Trim', price: 500, duration: '20 min', desc: 'Precision beard shaping and grooming', icon: '🧔' },
  { name: 'Hair Wash', price: 300, duration: '15 min', desc: 'Deep cleanse with premium shampoo & conditioner', icon: '💧' },
  { name: 'VIP Grooming', price: 2500, duration: '90 min', desc: 'Complete head-to-toe luxury grooming package', icon: '💎' },
  { name: 'Kids Haircut', price: 700, duration: '30 min', desc: 'Gentle, fun haircuts for children under 12', icon: '👦' },
  { name: 'Hair Coloring', price: 2000, duration: '60 min', desc: 'Professional color treatments & highlights', icon: '🎨' },
];

const TESTIMONIALS = [
  { name: "Michael Ng'ang'a", text: 'Best barbershop in Nairobi, hands down. Consistently delivers a perfect fade every time.', rating: 5, date: '2 weeks ago' },
  { name: 'Geoffrey Mutua', text: 'The VIP package is completely worth every shilling. Felt like a completely different person walking out.', rating: 5, date: '1 month ago' },
  { name: 'Daniel Odhiambo', text: 'Booked online in seconds and the slot was exactly as listed. Professional, punctual, and the cut was on point.', rating: 5, date: '3 weeks ago' },
  { name: 'Anthony Kiprono', text: "Brought my son for his first real haircut. The barbers were patient, gentle, and he actually enjoyed it!", rating: 5, date: '2 months ago' },
  { name: 'Victor Njoroge', text: 'M-Pesa payment is super convenient. The whole experience is seamless and premium.', rating: 5, date: '1 week ago' },
  { name: 'Elijah Mburu', text: 'James did an incredible beard trim. The attention to detail is unmatched. Elite Cuts truly lives up to its name.', rating: 5, date: '3 days ago' },
];

const INVENTORY = [
  { name: 'Professional Clippers', qty: 12, reorder: 4, icon: '✂', unit: 'units' },
  { name: 'Shaving Cream (250ml)', qty: 3, reorder: 10, icon: '🧴', unit: 'bottles' },
  { name: 'Premium Shampoo', qty: 8, reorder: 5, icon: '💧', unit: 'bottles' },
  { name: 'Fresh Towels', qty: 45, reorder: 20, icon: '🧣', unit: 'pieces' },
  { name: 'Beard Oil', qty: 15, reorder: 8, icon: '💆', unit: 'bottles' },
  { name: 'Hair Dye Kit', qty: 2, reorder: 5, icon: '🎨', unit: 'kits' },
];

const CUSTOMERS = [
  { name: "Michael Ng'ang'a", phone: '+254 712 345 678', visits: 14, spent: 18200, loyalty: 820, joined: 'Jan 2023' },
  { name: 'Geoffrey Mutua', phone: '+254 722 456 789', visits: 8, spent: 24500, loyalty: 1200, joined: 'Mar 2023' },
  { name: 'Daniel Odhiambo', phone: '+254 733 567 890', visits: 5, spent: 6500, loyalty: 320, joined: 'Aug 2023' },
];

async function seed() {
  const uri = process.env.MONGODB_URI;
  if (!uri) { console.error('✗ MONGODB_URI not set — copy .env.example to .env first.'); process.exit(1); }
  const dbName = await connectDB();
  console.log('✓ Connected to MongoDB for seeding' + (dbName ? ` (database: ${dbName})` : ''));

  async function seedIfEmpty(Model, data, label) {
    const count = await Model.countDocuments();
    if (count > 0) { console.log(`- ${label}: already has ${count} document(s), skipping`); return; }
    await Model.insertMany(data);
    console.log(`✓ ${label}: inserted ${data.length}`);
  }

  await seedIfEmpty(Barber, BARBERS, 'Barbers');
  await seedIfEmpty(Service, SERVICES, 'Services');
  await seedIfEmpty(Testimonial, TESTIMONIALS, 'Testimonials');
  await seedIfEmpty(InventoryItem, INVENTORY, 'Inventory');
  await seedIfEmpty(Customer, CUSTOMERS, 'Customers');

  const apptCount = await Appointment.countDocuments();
  if (apptCount === 0) {
    await Appointment.insertMany([
      { ref: 'ELT-1001', customer: "Michael Ng'ang'a", service: 'Haircut', barber: 'Peter Otieno', date: '2026-07-15', time: '10:00 AM', status: 'confirmed', amount: 1000 },
      { ref: 'ELT-1002', customer: 'Geoffrey Mutua', service: 'VIP Grooming', barber: 'James Kyalo', date: '2026-07-15', time: '11:30 AM', status: 'pending', amount: 2500 },
    ]);
    console.log('✓ Appointments: inserted 2 sample bookings');
  } else {
    console.log(`- Appointments: already has ${apptCount} document(s), skipping`);
  }

  let settings = await Settings.findOne();
  if (!settings) {
    const defaultPassword = process.env.ADMIN_PASSWORD || 'admin123';
    const adminPasswordHash = await bcrypt.hash(defaultPassword, 10);
    settings = await Settings.create({ adminPasswordHash });
    console.log(`✓ Settings: created with admin password "${defaultPassword}"`);
  } else {
    console.log('- Settings: already exists, skipping');
  }

  console.log('\nDone. Run `npm start` and open http://localhost:3000\n');
  await mongoose.disconnect();
}

seed().catch(err => { console.error(err); process.exit(1); });
