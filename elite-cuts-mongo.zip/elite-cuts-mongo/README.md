# Elite Cuts Kenya — MongoDB Edition

The barbershop site, booking flow, and admin dashboard, now backed by a real
Express + MongoDB server instead of browser storage. Barbers, services,
testimonials, inventory, appointments, customers, and all website content
live in your MongoDB database and are served over a REST API.

## What changed from the standalone HTML version

- **Real database.** Every collection (barbers, services, testimonials,
  inventory, appointments, customers) is its own MongoDB collection via
  Mongoose. Website content (business info, hero text, theme colors, hours,
  contact, social links, loyalty rules) lives in a single `Settings` document.
- **Real admin authentication.** The admin password is stored as a bcrypt
  hash in MongoDB, not in the page's JavaScript. Logging in gets you a signed
  session token (JWT) that's required for every write. This is a genuine
  improvement over the old client-side-only password gate.
- **Public vs. admin data.** Barbers, services, testimonials, and site
  settings are readable by anyone (that's what makes the homepage work).
  Appointments, customers, and inventory are business-sensitive and require
  an admin session to even read.
- **Customer accounts are still a demo.** The "My Account" customer login
  is unchanged from before — a simulated login, not tied to a real user
  system. Building real customer accounts (signup, password reset, "my
  bookings") is a separate, larger feature; this project wires up the
  business/admin side of the data. Bookings customers make ARE saved for
  real, the admin just doesn't have a per-customer login to view them in.

## Project structure

```
elite-cuts-mongo/
├── server.js              Express app entry point
├── seed.js                 One-time script to populate demo content
├── models/                 Mongoose schemas (one per collection)
├── routes/                 REST API endpoints
├── middleware/              Auth (JWT), the CRUD route factory, DB connection
├── public/index.html        The site itself (frontend calls the API via fetch)
├── test/                   A small test suite (see "Verifying it works" below)
└── .env.example             Copy to .env and fill in your own values
```

## Setup

**1. Install dependencies**
```
npm install
```

**2. Configure your environment**

Copy `.env.example` to `.env`:
```
cp .env.example .env
```

Then open `.env` and fill in:

- `MONGODB_URI` — your connection string. Based on what you shared, it'll look like:
  ```
  mongodb+srv://kelvinonyaki97_db_user:YOUR_ACTUAL_PASSWORD@cluster0.hf9hjpr.mongodb.net/?appName=Cluster0
  ```
  Replace `YOUR_ACTUAL_PASSWORD` with your real database user password. If it
  contains special characters (`@`, `:`, `/`, `%`, etc.), URL-encode them —
  e.g. `@` becomes `%40`.

  Your string has nothing between `.net/` and `?`, which means Mongoose would
  otherwise land in MongoDB's default `test` database. The app handles this
  automatically and uses a database named `eliteCutsKenya` instead (see
  `MONGODB_DBNAME` in `.env.example` if you want a different name).

- `JWT_SECRET` — any long random string, used to sign admin sessions. Generate one with:
  ```
  node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
  ```

- `ADMIN_PASSWORD` — only used the very first time the app runs against an
  empty database, to create the admin account. Defaults to `admin123` if you
  leave it blank. Change it from **Admin → Settings** after you log in —
  from then on it's whatever you set it to there, not this file.

**3. (Optional but recommended) Seed some starter content**

A brand-new database has no barbers, services, etc. — the homepage would be
empty. Populate it with the same demo content the original prototype shipped
with:
```
npm run seed
```
This is safe to re-run; it skips any collection that already has data.

**4. Start the server**
```
npm start
```
Then open **http://localhost:3000**.

## Using it

- The public site, booking flow, and demo customer login work exactly like before.
- Click the ⚙️ icon in the nav (or "Staff Login" in the footer) to sign in as
  admin — password is whatever you set in step 2 (or `admin123` by default).
- Barbers, services, testimonials, and inventory save to MongoDB the instant
  you add/edit/delete them.
- Business info, hero text, theme colors, hours, and contact details are
  batched locally as you type — click **Save & Publish** (top-right of the
  admin dashboard) to write them to MongoDB.
- **Settings** has an admin password change, a JSON export/import for the
  website-settings half of the data (handy for backups), and a "reset
  website settings to defaults" button (doesn't touch barbers/services/etc.).

## Deploying it somewhere permanent

Right now this only runs on your own machine. To make it reachable on the
internet, deploy it to any Node hosting provider (Render, Railway, Fly.io,
a VPS, etc.) — the steps are broadly:
1. Push this folder to a Git repository.
2. Create a new Node web service on the platform, pointed at that repo.
3. Set the same three environment variables (`MONGODB_URI`, `JWT_SECRET`,
   `ADMIN_PASSWORD`) in the platform's dashboard instead of a `.env` file.
4. Set the start command to `npm start`.

If you tell me which platform you'd like to use, I can walk through that
specific setup.

## Verifying it works

There's no real MongoDB available in the sandbox I built this in, so I
couldn't test against your actual Atlas cluster directly. Instead, `test/`
contains an in-memory stand-in for MongoDB that mimics the exact Mongoose
methods this app uses, so the whole stack — API routes, auth, and the real
frontend making real HTTP requests — could be exercised end-to-end without
a live database. Run it yourself with:
```
npm test
```
This does **not** touch your real database or `.env` — it's fully self-contained.
I'd still recommend clicking through the real thing once it's running against
your actual MongoDB, just to be sure (e.g. add a barber, refresh the page,
confirm it's still there).

## Security notes

- The admin password is bcrypt-hashed and sessions are signed JWTs — this is
  real server-side auth, a meaningful step up from the old client-side gate.
- That said, this is still a small-business tool, not a hardened production
  system: there's no rate-limiting on the login endpoint, no HTTPS handled by
  the app itself (put it behind a reverse proxy / your hosting platform's
  TLS termination), and no audit logging. Fine for a single-shop admin tool;
  I'd harden further before handling anything more sensitive.
- Never commit your `.env` file — it's already in `.gitignore`.
