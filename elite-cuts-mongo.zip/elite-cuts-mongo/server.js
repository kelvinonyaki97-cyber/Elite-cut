require('dotenv').config({ quiet: true });
const path = require('path');
const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const { connectDB } = require('./middleware/connectDB');

const app = express();

app.use(cors());
app.use(express.json({ limit: '1mb' }));

// ── API routes ──
app.use('/api/admin', require('./routes/admin'));
app.use('/api/settings', require('./routes/settings'));
app.use('/api/barbers', require('./routes/barbers'));
app.use('/api/services', require('./routes/services'));
app.use('/api/testimonials', require('./routes/testimonials'));
app.use('/api/inventory', require('./routes/inventory'));
app.use('/api/appointments', require('./routes/appointments'));
app.use('/api/customers', require('./routes/customers'));

app.get('/api/health', (req, res) => {
  res.json({ ok: true, dbState: mongoose.connection.readyState });
});

// ── Frontend ──
app.use(express.static(path.join(__dirname, 'public')));
app.use((req, res) => {
  if (req.path.startsWith('/api/')) return res.status(404).json({ message: 'Not found.' });
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// ── Error fallback ──
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: 'Unexpected server error.' });
});

const PORT = process.env.PORT || 3000;
const MONGODB_URI = process.env.MONGODB_URI;

async function start() {
  if (!MONGODB_URI) {
    console.error('\n✗ MONGODB_URI is not set. Copy .env.example to .env and fill in your connection string.\n');
    process.exit(1);
  }
  if (!process.env.JWT_SECRET) {
    console.error('\n✗ JWT_SECRET is not set. Copy .env.example to .env and set a random secret string.\n');
    process.exit(1);
  }
  try {
    const dbName = await connectDB();
    console.log('✓ Connected to MongoDB' + (dbName ? ` (database: ${dbName})` : ''));
    app.listen(PORT, () => {
      console.log(`✓ Elite Cuts Kenya server running at http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('✗ Could not connect to MongoDB:', err.message);
    process.exit(1);
  }
}

// Only auto-start when run directly (so tests can import `app` without opening a real connection/port)
if (require.main === module) {
  start();
}

module.exports = { app, start };
