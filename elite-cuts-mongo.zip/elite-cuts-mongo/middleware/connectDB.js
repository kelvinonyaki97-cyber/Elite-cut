const mongoose = require('mongoose');

/**
 * Connects to MongoDB using MONGODB_URI. If the connection string doesn't
 * specify a database name (e.g. the Atlas "Connect your application"
 * template, which ends in "/?..." with nothing between the host and the
 * "?"), we fall back to a named database instead of silently landing in
 * Mongo's default "test" database.
 */
async function connectDB() {
  const uri = process.env.MONGODB_URI;
  if (!uri) throw new Error('MONGODB_URI is not set.');
  const hasDbName = /\.net\/[A-Za-z0-9_-]+(\?|$)/.test(uri) || /:\d+\/[A-Za-z0-9_-]+(\?|$)/.test(uri);
  const opts = hasDbName ? {} : { dbName: process.env.MONGODB_DBNAME || 'eliteCutsKenya' };
  await mongoose.connect(uri, opts);
  return opts.dbName || null;
}

module.exports = { connectDB };
