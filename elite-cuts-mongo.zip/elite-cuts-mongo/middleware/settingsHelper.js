const bcrypt = require('bcryptjs');
const Settings = require('../models/Settings');

async function getOrCreateSettings() {
  let settings = await Settings.findOne();
  if (!settings) {
    const defaultPassword = process.env.ADMIN_PASSWORD || 'admin123';
    const adminPasswordHash = await bcrypt.hash(defaultPassword, 10);
    settings = await Settings.create({ adminPasswordHash });
    console.log(`\n[elite-cuts] No Settings document found — created one with the default admin password: "${defaultPassword}"`);
    console.log('[elite-cuts] Change it from Admin → Settings as soon as you log in.\n');
  }
  return settings;
}

module.exports = { getOrCreateSettings };
