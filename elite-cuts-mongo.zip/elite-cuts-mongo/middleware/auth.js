const jwt = require('jsonwebtoken');

const JWT_SECRET = process.env.JWT_SECRET;

function signAdminToken() {
  return jwt.sign({ role: 'admin' }, JWT_SECRET, { expiresIn: '12h' });
}

function requireAdmin(req, res, next) {
  const header = req.headers.authorization || '';
  const token = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ message: 'Missing admin token. Please sign in.' });
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    if (payload.role !== 'admin') throw new Error('bad role');
    req.admin = payload;
    next();
  } catch (e) {
    return res.status(401).json({ message: 'Invalid or expired admin session. Please sign in again.' });
  }
}

module.exports = { signAdminToken, requireAdmin };
