const express = require('express');
const { requireAdmin } = require('./auth');

/**
 * Builds a standard REST router for a Mongoose model.
 * @param {import('mongoose').Model} Model
 * @param {{ publicRead?: boolean }} opts  publicRead=true means GET / and GET /:id need no auth
 *   (used for content that renders on the public marketing site: barbers, services, testimonials).
 *   Everything else (POST/PUT/DELETE) always requires the admin token.
 */
function makeCrudRouter(Model, opts = {}) {
  const router = express.Router();
  const readGuard = opts.publicRead ? (req, res, next) => next() : requireAdmin;

  router.get('/', readGuard, async (req, res) => {
    try {
      const docs = await Model.find().sort({ createdAt: 1 });
      res.json(docs);
    } catch (e) {
      res.status(500).json({ message: 'Could not load records.', error: e.message });
    }
  });

  router.post('/', requireAdmin, async (req, res) => {
    try {
      const doc = await Model.create(req.body);
      res.status(201).json(doc);
    } catch (e) {
      res.status(400).json({ message: 'Could not create record.', error: e.message });
    }
  });

  router.put('/:id', requireAdmin, async (req, res) => {
    try {
      const doc = await Model.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
      if (!doc) return res.status(404).json({ message: 'Not found.' });
      res.json(doc);
    } catch (e) {
      res.status(400).json({ message: 'Could not update record.', error: e.message });
    }
  });

  router.delete('/:id', requireAdmin, async (req, res) => {
    try {
      const doc = await Model.findByIdAndDelete(req.params.id);
      if (!doc) return res.status(404).json({ message: 'Not found.' });
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({ message: 'Could not delete record.', error: e.message });
    }
  });

  return router;
}

module.exports = { makeCrudRouter };
