const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema({
  business: {
    name:    { type: String, default: 'Elite Cuts Kenya' },
    tagline: { type: String, default: 'Precision. Style. Excellence.' },
    about:   { type: String, default: "Elite Cuts Kenya was born from a passion for precision and a belief that every man deserves to look and feel his absolute best. We've grown from a single chair in Westlands to Nairobi's most trusted luxury barbershop." },
    years:   { type: String, default: '1+' },
    clients: { type: String, default: '1K+' },
    rating:  { type: String, default: '4.9★' },
    award:   { type: String, default: "Nairobi's Best Barbershop 2023 & 2024" },
  },
  hero: {
    l1:   { type: String, default: 'Precision.' },
    l2:   { type: String, default: 'Style.' },
    l3:   { type: String, default: 'Excellence.' },
    sub:  { type: String, default: 'Where every cut is a masterpiece. Experience luxury grooming in the heart of Nairobi, crafted for the modern gentleman.' },
    btn1: { type: String, default: 'Book Appointment' },
    btn2: { type: String, default: 'View Services' },
    loc:  { type: String, default: 'Premium Barbershop — Nairobi, Kenya' },
  },
  theme: {
    gold:  { type: String, default: '#C9A84C' },
    black: { type: String, default: '#0A0A0A' },
    dark:  { type: String, default: '#111111' },
    dark2: { type: String, default: '#1A1A1A' },
  },
  contact: {
    phone:    { type: String, default: '+254 745990964' },
    whatsapp: { type: String, default: '+254 745990964' },
    email:    { type: String, default: 'elitecutskenya.co.ke' },
    addr1:    { type: String, default: 'Westlands Square, 3rd Floor' },
    addr2:    { type: String, default: 'Nairobi, Kenya' },
  },
  social: {
    ig: { type: String, default: '' },
    fb: { type: String, default: '' },
    tw: { type: String, default: '' },
    yt: { type: String, default: '' },
    tt: { type: String, default: '' },
  },
  loyalty: {
    perKES:         { type: Number, default: 10 },
    goldThreshold:  { type: Number, default: 500 },
    goldBenefit:    { type: String, default: '10% discount on all services' },
    birthdayBonus:  { type: Number, default: 50 },
    referralBonus:  { type: Number, default: 100 },
  },
  hours: {
    type: [{ day: String, open: String, close: String, _id: false }],
    default: [
      { day: 'Monday – Friday', open: '8:00 AM', close: '8:00 PM' },
      { day: 'Saturday', open: '8:00 AM', close: '7:00 PM' },
      { day: 'Sunday', open: '10:00 AM', close: '5:00 PM' },
    ],
  },
  adminPasswordHash: { type: String, required: true },
}, { timestamps: true });

module.exports = mongoose.model('Settings', settingsSchema);
