const mongoose = require('mongoose');

const inventoryItemSchema = new mongoose.Schema({
  name:    { type: String, required: true, trim: true },
  qty:     { type: Number, default: 0 },
  reorder: { type: Number, default: 5 },
  icon:    { type: String, default: '📦' },
  unit:    { type: String, default: 'units' },
}, { timestamps: true });

module.exports = mongoose.model('InventoryItem', inventoryItemSchema);
