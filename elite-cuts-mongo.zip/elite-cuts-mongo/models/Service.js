const mongoose = require('mongoose');

const serviceSchema = new mongoose.Schema({
  name:     { type: String, required: true, trim: true },
  price:    { type: Number, required: true, min: 0 },
  duration: { type: String, default: '30 min' },
  desc:     { type: String, default: '' },
  icon:     { type: String, default: '✂' },
}, { timestamps: true });

module.exports = mongoose.model('Service', serviceSchema);
