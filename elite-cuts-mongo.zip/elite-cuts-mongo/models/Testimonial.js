const mongoose = require('mongoose');

const testimonialSchema = new mongoose.Schema({
  name:   { type: String, required: true, trim: true },
  text:   { type: String, required: true },
  rating: { type: Number, default: 5, min: 1, max: 5 },
  date:   { type: String, default: 'Just now' },
}, { timestamps: true });

module.exports = mongoose.model('Testimonial', testimonialSchema);
