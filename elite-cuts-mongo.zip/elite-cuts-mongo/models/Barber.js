const mongoose = require('mongoose');

const barberSchema = new mongoose.Schema({
  name:      { type: String, required: true, trim: true },
  specialty: { type: String, default: '' },
  exp:       { type: Number, default: 1 },
  rating:    { type: Number, default: 4.8, min: 1, max: 5 },
  avatar:    { type: String, default: '✂' },
  reviews:   { type: Number, default: 0 },
}, { timestamps: true });

module.exports = mongoose.model('Barber', barberSchema);
