const mongoose = require('mongoose');

const appointmentSchema = new mongoose.Schema({
  ref:      { type: String, required: true, unique: true },
  customer: { type: String, required: true, trim: true },
  service:  { type: String, required: true },
  barber:   { type: String, required: true },
  date:     { type: String, default: 'TBC' },
  time:     { type: String, default: 'TBC' },
  status:   { type: String, enum: ['pending', 'confirmed', 'completed', 'cancelled'], default: 'pending' },
  amount:   { type: Number, default: 0 },
}, { timestamps: true });

module.exports = mongoose.model('Appointment', appointmentSchema);
