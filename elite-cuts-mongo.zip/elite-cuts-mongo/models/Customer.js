const mongoose = require('mongoose');

const customerSchema = new mongoose.Schema({
  name:    { type: String, required: true, trim: true },
  phone:   { type: String, default: '' },
  visits:  { type: Number, default: 0 },
  spent:   { type: Number, default: 0 },
  loyalty: { type: Number, default: 0 },
  joined:  { type: String, default: () => new Date().toLocaleString('default', { month: 'short', year: 'numeric' }) },
}, { timestamps: true });

module.exports = mongoose.model('Customer', customerSchema);
