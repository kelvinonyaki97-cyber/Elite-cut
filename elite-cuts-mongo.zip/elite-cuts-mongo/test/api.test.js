process.env.JWT_SECRET = 'test-secret-key-for-local-testing-only';
process.env.ADMIN_PASSWORD = 'admin123';

const path = require('path');
const request = require('supertest');
const { createFakeModel } = require('./fakeModel');

const FakeSettings = createFakeModel({});
const FakeBarber = createFakeModel({ specialty: '', exp: 1, rating: 4.8, avatar: '✂', reviews: 0 }, ['name']);
const FakeService = createFakeModel({ duration: '30 min', desc: '', icon: '✂' }, ['name', 'price']);
const FakeTestimonial = createFakeModel({ rating: 5, date: 'Just now' }, ['name', 'text']);
const FakeInventoryItem = createFakeModel({ qty: 0, reorder: 5, icon: '📦', unit: 'units' }, ['name']);
const FakeAppointment = createFakeModel({ status: 'pending', amount: 0 }, ['ref', 'customer', 'service', 'barber']);
const FakeCustomer = createFakeModel({ visits: 0, spent: 0, loyalty: 0, joined: '—' }, ['name']);

// Mongoose Settings schema applies its own field-level defaults via `new Settings()`,
// but our fake model's create() doesn't run Mongoose schema defaults, so seed them here
// to mirror models/Settings.js's declared defaults for a realistic test.
const SETTINGS_SCHEMA_DEFAULTS = {
  business: { name:'Elite Cuts Kenya', tagline:'Precision. Style. Excellence.', about:"Elite Cuts Kenya was born from a passion for precision and a belief that every man deserves to look and feel his absolute best. We've grown from a single chair in Westlands to Nairobi's most trusted luxury barbershop.", years:'1+', clients:'1K+', rating:'4.9★', award:"Nairobi's Best Barbershop 2023 & 2024" },
  hero: { l1:'Precision.', l2:'Style.', l3:'Excellence.', sub:'Where every cut is a masterpiece. Experience luxury grooming in the heart of Nairobi, crafted for the modern gentleman.', btn1:'Book Appointment', btn2:'View Services', loc:'Premium Barbershop — Nairobi, Kenya' },
  theme: { gold:'#C9A84C', black:'#0A0A0A', dark:'#111111', dark2:'#1A1A1A' },
  contact: { phone:'+254 745990964', whatsapp:'+254 745990964', email:'elitecutskenya.co.ke', addr1:'Westlands Square, 3rd Floor', addr2:'Nairobi, Kenya' },
  social: { ig:'', fb:'', tw:'', yt:'', tt:'' },
  loyalty: { perKES:10, goldThreshold:500, goldBenefit:'10% discount on all services', birthdayBonus:50, referralBonus:100 },
  hours: [
    { day:'Monday – Friday', open:'8:00 AM', close:'8:00 PM' },
    { day:'Saturday', open:'8:00 AM', close:'7:00 PM' },
    { day:'Sunday', open:'10:00 AM', close:'5:00 PM' },
  ],
};
FakeSettings.create = (function(orig){
  return async (data) => orig(Object.assign({}, SETTINGS_SCHEMA_DEFAULTS, data));
})(FakeSettings.create);

// ── Inject fakes directly into Node's require cache, so every file that does
// require('../models/X') anywhere in the app gets our in-memory fake instead
// of the real Mongoose model. This sidesteps needing a real MongoDB engine,
// which isn't available in this sandbox (no internet access to download one).
function stubModule(relPathFromHere, exportsObj) {
  const resolved = require.resolve(relPathFromHere);
  require.cache[resolved] = { id: resolved, filename: resolved, loaded: true, exports: exportsObj };
}
stubModule('../models/Settings.js', FakeSettings);
stubModule('../models/Barber.js', FakeBarber);
stubModule('../models/Service.js', FakeService);
stubModule('../models/Testimonial.js', FakeTestimonial);
stubModule('../models/InventoryItem.js', FakeInventoryItem);
stubModule('../models/Appointment.js', FakeAppointment);
stubModule('../models/Customer.js', FakeCustomer);
stubModule('../middleware/connectDB.js', { connectDB: async () => 'test' });

const { app } = require('../server.js');

let pass = 0, fail = 0;
function check(label, cond, extra) {
  if (cond) { pass++; console.log('PASS - ' + label); }
  else { fail++; console.log('FAIL - ' + label + (extra ? ' -> ' + JSON.stringify(extra) : '')); }
}

let adminToken = null;
let barberId = null;
let serviceId = null;
let apptId = null;

(async () => {
  // ── Public settings ──
  let res = await request(app).get('/api/settings');
  check('GET /api/settings -> 200', res.status === 200, res.body);
  check('settings has business.name default', res.body.business && res.body.business.name === 'Elite Cuts Kenya');
  check('settings never leaks adminPasswordHash', res.body.adminPasswordHash === undefined);

  // ── Admin login: wrong password ──
  res = await request(app).post('/api/admin/login').send({ password: 'wrong' });
  check('login with wrong password -> 401', res.status === 401, res.body);

  // ── Admin login: correct password ──
  res = await request(app).post('/api/admin/login').send({ password: 'admin123' });
  check('login with correct password -> 200 + token', res.status === 200 && !!res.body.token, res.body);
  adminToken = res.body.token;

  // ── Barbers: public read, admin write ──
  res = await request(app).get('/api/barbers');
  check('GET /api/barbers (public) -> 200 empty array', res.status === 200 && Array.isArray(res.body) && res.body.length === 0);

  res = await request(app).post('/api/barbers').send({ name: 'Test Barber' });
  check('POST /api/barbers without auth -> 401', res.status === 401);

  res = await request(app).post('/api/barbers').set('Authorization', 'Bearer ' + adminToken).send({ name: 'Peter Otieno', specialty: 'Fades', exp: 5, rating: 4.9 });
  check('POST /api/barbers with auth -> 201', res.status === 201 && res.body.name === 'Peter Otieno', res.body);
  barberId = res.body._id;
  check('created barber has _id', !!barberId);

  res = await request(app).get('/api/barbers');
  check('GET /api/barbers now returns 1', res.body.length === 1);

  res = await request(app).put('/api/barbers/' + barberId).set('Authorization', 'Bearer ' + adminToken).send({ rating: 5 });
  check('PUT /api/barbers/:id updates rating', res.status === 200 && res.body.rating === 5, res.body);

  res = await request(app).delete('/api/barbers/' + barberId).set('Authorization', 'Bearer ' + adminToken);
  check('DELETE /api/barbers/:id -> 200', res.status === 200);
  res = await request(app).get('/api/barbers');
  check('barbers empty again after delete', res.body.length === 0);

  // re-add for later use in appointment test
  res = await request(app).post('/api/barbers').set('Authorization', 'Bearer ' + adminToken).send({ name: 'James Kyalo' });
  barberId = res.body._id;

  // ── Services ──
  res = await request(app).post('/api/services').set('Authorization', 'Bearer ' + adminToken).send({ name: 'Haircut', price: 1000, duration: '45 min' });
  check('POST /api/services -> 201', res.status === 201, res.body);
  serviceId = res.body._id;

  res = await request(app).post('/api/services').set('Authorization', 'Bearer ' + adminToken).send({ name: 'Bad Service' });
  check('POST /api/services without required price -> 400', res.status === 400, res.body);

  // ── Testimonials ──
  res = await request(app).post('/api/testimonials').set('Authorization', 'Bearer ' + adminToken).send({ name: 'Michael', text: 'Great cut!' });
  check('POST /api/testimonials -> 201', res.status === 201);

  // ── Inventory (not publicly readable) ──
  res = await request(app).get('/api/inventory');
  check('GET /api/inventory without auth -> 401 (business-sensitive)', res.status === 401);
  res = await request(app).get('/api/inventory').set('Authorization', 'Bearer ' + adminToken);
  check('GET /api/inventory with auth -> 200', res.status === 200);

  // ── Customers (not publicly readable) ──
  res = await request(app).get('/api/customers');
  check('GET /api/customers without auth -> 401', res.status === 401);

  // ── Appointments: public create, admin manage ──
  res = await request(app).post('/api/appointments').send({ customer: 'Jane Doe', service: 'Haircut', barber: 'James Kyalo', date: '2026-07-15', time: '10:00 AM', amount: 1000 });
  check('POST /api/appointments (public, no auth) -> 201', res.status === 201 && !!res.body.ref, res.body);
  apptId = res.body._id;

  res = await request(app).get('/api/appointments');
  check('GET /api/appointments without auth -> 401', res.status === 401);
  res = await request(app).get('/api/appointments').set('Authorization', 'Bearer ' + adminToken);
  check('GET /api/appointments with auth -> 200, contains booking', res.status === 200 && res.body.length === 1);

  res = await request(app).put('/api/appointments/' + apptId).set('Authorization', 'Bearer ' + adminToken).send({ status: 'confirmed' });
  check('PUT appointment status -> confirmed', res.status === 200 && res.body.status === 'confirmed', res.body);

  // ── Settings update (admin only) ──
  res = await request(app).put('/api/settings').send({ business: { name: 'Hacked Shop' } });
  check('PUT /api/settings without auth -> 401', res.status === 401);

  res = await request(app).put('/api/settings').set('Authorization', 'Bearer ' + adminToken).send({ business: { name: 'Elite Cuts Nairobi' } });
  check('PUT /api/settings with auth updates business.name', res.status === 200 && res.body.business.name === 'Elite Cuts Nairobi', res.body);
  check('PUT /api/settings preserves other business fields (partial update)', res.body.business.tagline === 'Precision. Style. Excellence.', res.body.business);

  // ── Admin password change ──
  res = await request(app).put('/api/admin/password').set('Authorization', 'Bearer ' + adminToken).send({ currentPassword: 'wrong', newPassword: 'newpass123' });
  check('change password with wrong current -> 401', res.status === 401);

  res = await request(app).put('/api/admin/password').set('Authorization', 'Bearer ' + adminToken).send({ currentPassword: 'admin123', newPassword: 'newpass123' });
  check('change password with correct current -> 200', res.status === 200, res.body);

  res = await request(app).post('/api/admin/login').send({ password: 'admin123' });
  check('old password no longer works', res.status === 401);
  res = await request(app).post('/api/admin/login').send({ password: 'newpass123' });
  check('new password works', res.status === 200 && !!res.body.token);

  // ── Invalid/garbage token ──
  res = await request(app).get('/api/appointments').set('Authorization', 'Bearer garbage.token.here');
  check('garbage JWT -> 401', res.status === 401);

  // ── Frontend static file serving ──
  res = await request(app).get('/');
  check('GET / serves index.html', res.status === 200 && res.text.includes('<title>') , { len: res.text.length });

  res = await request(app).get('/api/does-not-exist');
  check('unknown /api/ route -> 404 json', res.status === 404 && res.body.message);

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})();
