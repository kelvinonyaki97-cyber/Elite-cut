// A minimal stand-in for a Mongoose Model, implementing only the methods
// our routes actually call: find().sort(), create(), findById*, exists(),
// countDocuments(), findOne(), and document instances with .save()/.toObject().
// Used only for local testing (no real MongoDB engine available in this sandbox).
const crypto = require('crypto');

function fakeId() { return crypto.randomBytes(12).toString('hex'); }

function createFakeModel(defaults = {}, required = []) {
  var store = [];

  function makeDoc(obj) {
    const doc = Object.assign({ _id: obj._id || fakeId(), createdAt: new Date(), updatedAt: new Date() }, obj);
    doc.toObject = function () { const c = Object.assign({}, doc); delete c.toObject; delete c.save; return c; };
    doc.save = async function () {
      doc.updatedAt = new Date();
      const idx = store.findIndex(d => d._id === doc._id);
      if (idx > -1) store[idx] = doc;
      return doc;
    };
    return doc;
  }

  function applyDefaults(obj) {
    const merged = JSON.parse(JSON.stringify(defaults));
    return deepMerge(merged, obj);
  }
  function deepMerge(base, override) {
    for (const k in override) {
      if (override[k] && typeof override[k] === 'object' && !Array.isArray(override[k]) && base[k] && typeof base[k] === 'object') {
        deepMerge(base[k], override[k]);
      } else {
        base[k] = override[k];
      }
    }
    return base;
  }

  const Model = {
    _store: store,
    find: () => ({
      sort: async () => store.map(d => makeDoc(d)),
    }),
    findOne: async (query) => {
      if (!query) return store.length ? makeDoc(store[0]) : null;
      const found = store.find(d => Object.keys(query).every(k => String(d[k]) === String(query[k])));
      return found ? makeDoc(found) : null;
    },
    findById: async (id) => {
      const found = store.find(d => d._id === id);
      return found ? makeDoc(found) : null;
    },
    findByIdAndUpdate: async (id, updates, opts) => {
      const idx = store.findIndex(d => d._id === id);
      if (idx === -1) return null;
      store[idx] = deepMerge(Object.assign({}, store[idx]), updates);
      store[idx].updatedAt = new Date();
      return makeDoc(store[idx]);
    },
    findByIdAndDelete: async (id) => {
      const idx = store.findIndex(d => d._id === id);
      if (idx === -1) return null;
      const [removed] = store.splice(idx, 1);
      return makeDoc(removed);
    },
    create: async (data) => {
      const missing = required.filter(f => data[f] === undefined || data[f] === null || data[f] === '');
      if (missing.length) {
        const err = new Error(`Path \`${missing[0]}\` is required.`);
        err.name = 'ValidationError';
        throw err;
      }
      const withDefaults = applyDefaults(data);
      const doc = makeDoc(Object.assign({ _id: fakeId() }, withDefaults));
      store.push(doc);
      return makeDoc(doc);
    },
    insertMany: async (arr) => {
      const created = arr.map(d => Object.assign({ _id: fakeId() }, applyDefaults(d)));
      store.push(...created);
      return created.map(d => makeDoc(d));
    },
    countDocuments: async () => store.length,
    exists: async (query) => {
      const found = store.find(d => Object.keys(query).every(k => String(d[k]) === String(query[k])));
      return found ? { _id: found._id } : null;
    },
    __reset: () => { store.length = 0; },
  };
  return Model;
}

module.exports = { createFakeModel, fakeId };
