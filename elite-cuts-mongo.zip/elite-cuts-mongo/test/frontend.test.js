process.env.JWT_SECRET = 'test-secret-key-for-local-testing-only';
process.env.ADMIN_PASSWORD = 'admin123';
process.env.PORT = '3901';

const { createFakeModel } = require('./fakeModel');
const { JSDOM } = require('jsdom');

const FakeSettings = createFakeModel({});
const FakeBarber = createFakeModel({ specialty: '', exp: 1, rating: 4.8, avatar: '✂', reviews: 0 }, ['name']);
const FakeService = createFakeModel({ duration: '30 min', desc: '', icon: '✂' }, ['name', 'price']);
const FakeTestimonial = createFakeModel({ rating: 5, date: 'Just now' }, ['name', 'text']);
const FakeInventoryItem = createFakeModel({ qty: 0, reorder: 5, icon: '📦', unit: 'units' }, ['name']);
const FakeAppointment = createFakeModel({ status: 'pending', amount: 0 }, ['ref', 'customer', 'service', 'barber']);
const FakeCustomer = createFakeModel({ visits: 0, spent: 0, loyalty: 0, joined: '—' }, ['name']);

function stubModule(relPathFromHere, exportsObj) {
  const resolved = require.resolve(relPathFromHere);
  require.cache[resolved] = { id: resolved, filename: resolved, loaded: true, exports: exportsObj };
}
stubModule('../models/Settings.js', FakeSettings);
stubModule('../models/Barber.js', FakeBarber);
stubModule('../models/Service.js', FakeService);
stubModule('../models/Testimonial.js', FakeTestimonial);
stubModule('../models/InventoryItem.js', FakeInventoryItem);
stubModule('../models/Appointment.js', FakeAppointment);
stubModule('../models/Customer.js', FakeCustomer);
stubModule('../middleware/connectDB.js', { connectDB: async () => 'test' });

const { app } = require('../server.js');

let pass = 0, fail = 0;
function check(label, cond, extra) {
  if (cond) { pass++; console.log('PASS - ' + label); }
  else { fail++; console.log('FAIL - ' + label + (extra !== undefined ? ' -> ' + JSON.stringify(extra) : '')); }
}

(async () => {
  const base = 'http://localhost:3901';
  const fetch = (await import('node-fetch')).default;

  const server = app.listen(3901);
  await new Promise(r => setTimeout(r, 200));

  // Pre-seed some content via the real HTTP API before loading the page,
  // so the homepage has something to render (mirrors `npm run seed`).
  const loginRes = await fetch(base + '/api/admin/login', { method: 'POST', headers: {'Content-Type':'application/json'}, body: JSON.stringify({ password: 'admin123' }) });
  const { token } = await loginRes.json();
  const authed = (method, path, body) => fetch(base + path, { method, headers: { 'Content-Type':'application/json', Authorization: 'Bearer ' + token }, body: body ? JSON.stringify(body) : undefined });

  await authed('POST', '/api/barbers', { name: 'Peter Otieno', specialty: 'Classic Cuts & Fades', exp: 5, rating: 4.9, avatar: '💈', reviews: 87 });
  await authed('POST', '/api/services', { name: 'Haircut', price: 1000, duration: '45 min', desc: 'Classic cut', icon: '✂' });
  await authed('POST', '/api/services', { name: 'Beard Trim', price: 500, duration: '20 min', desc: 'Beard shaping', icon: '🧔' });
  await authed('POST', '/api/testimonials', { name: 'Michael', text: 'Great service!', rating: 5, date: 'today' });

  const errors = [];
  const htmlRes = await fetch(base + '/');
  const html = await htmlRes.text();
  const dom = new JSDOM(html, {
    runScripts: 'dangerously', resources: 'usable', url: base + '/', pretendToBeVisual: true,
    beforeParse(window) {
      window.fetch = (url, opts) => fetch(new URL(url, base).toString(), opts); // node-fetch needs absolute URLs
      window.onerror = (msg, src, line, col, err) => errors.push(`${msg} (line ${line}:${col})`);
    },
  });

  await new Promise(r => setTimeout(r, 400)); // let the async init() bootstrap run

  const doc = dom.window.document;
  const win = dom.window;

  check('barbersGrid populated from live API', doc.getElementById('barbersGrid').children.length === 1, doc.getElementById('barbersGrid').innerHTML.slice(0,80));
  check('servicesGrid populated from live API', doc.getElementById('servicesGrid').children.length === 2);
  check('testimonialsGrid populated from live API', doc.getElementById('testimonialsGrid').children.length === 1);
  check('hero business name reflected', win.document.title.includes('Elite Cuts Kenya'));

  // Booking flow against the real server
  win.showPage('booking');
  await new Promise(r => setTimeout(r, 50));
  check('booking page active', doc.getElementById('page-booking').classList.contains('active'));
  const svcId = win.eval('STATE.services[0]._id');
  const barId = win.eval('STATE.barbers[0]._id');
  win.selectService(svcId);
  win.selectBarber(barId);
  win.selectDate(new Date().toDateString(), '15 Jul 2026');
  win.selectTime('10:00 AM');
  await win.confirmBooking();
  await new Promise(r => setTimeout(r, 200));
  check('booking confirmation step shown', doc.getElementById('bookStep5').style.display === 'block');
  const bookingRef = doc.getElementById('bookingRef').textContent;
  check('booking ref looks like ELT-xxxx', /^ELT-\d{4}$/.test(bookingRef), bookingRef);

  // Verify it actually landed in the real (fake) DB via the API directly
  const apptCheck = await authed('GET', '/api/appointments').then(r => r.json());
  check('appointment created via booking flow exists server-side', apptCheck.some(a => a.ref === bookingRef), apptCheck.map(a=>a.ref));

  // Admin login through the real UI + real server
  win.gearClicked();
  await new Promise(r => setTimeout(r, 50));
  const passInput = doc.getElementById('adminPassInput');
  check('admin login modal opened', !!passInput);
  passInput.value = 'admin123';
  await win.attemptAdminLogin();
  await new Promise(r => setTimeout(r, 300));
  check('admin dashboard active after real login', doc.getElementById('page-adminDash').classList.contains('active'));
  check('appointments loaded into admin STATE', win.eval('STATE.appointments.length') >= 1);

  // Walk every admin section against the live server-backed STATE
  const sections = ['dashboard','appointments','barbers','services','testimonials','inventory','business','hero','theme','hours','loyalty','payments','reports','customers','settings'];
  for (const s of sections) {
    win.showAdminSection(s);
    await new Promise(r => setTimeout(r, 20));
    const content = doc.getElementById('adminContent').innerHTML;
    check(`admin section "${s}" rendered`, !!content && content.trim().length > 0);
  }

  // Real CRUD round-trip: add a barber via the admin UI, confirm it persists server-side
  win.showAdminSection('barbers');
  win.openAddBarber();
  await new Promise(r => setTimeout(r, 30));
  doc.getElementById('nb-name').value = 'James Kyalo';
  doc.getElementById('nb-spec').value = 'Modern Styles';
  await win.addBarber();
  await new Promise(r => setTimeout(r, 200));
  const barbersServerSide = await fetch(base + '/api/barbers').then(r => r.json());
  check('newly added barber persisted server-side', barbersServerSide.some(b => b.name === 'James Kyalo'), barbersServerSide.map(b=>b.name));

  // Settings save round-trip
  win.updateBiz('name', 'Elite Cuts Test Shop');
  await win.saveState();
  await new Promise(r => setTimeout(r, 200));
  const settingsServerSide = await fetch(base + '/api/settings').then(r => r.json());
  check('business name change persisted server-side', settingsServerSide.business.name === 'Elite Cuts Test Shop', settingsServerSide.business.name);
  check('homepage title updated after save', win.document.title.includes('Elite Cuts Test Shop'));

  console.log('\n--- JS runtime errors captured ---');
  console.log(errors.length ? errors.join('\n') : 'none');
  console.log(`\n${pass} passed, ${fail} failed`);

  server.close();
  process.exit(fail || errors.length ? 1 : 0);
})().catch(e => { console.error('TEST CRASHED:', e); process.exit(1); });
