const { makeCrudRouter } = require('../middleware/crudFactory');
const Barber = require('../models/Barber');
module.exports = makeCrudRouter(Barber, { publicRead: true });
