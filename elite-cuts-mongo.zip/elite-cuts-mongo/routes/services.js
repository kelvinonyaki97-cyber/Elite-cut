const { makeCrudRouter } = require('../middleware/crudFactory');
const Service = require('../models/Service');
module.exports = makeCrudRouter(Service, { publicRead: true });
