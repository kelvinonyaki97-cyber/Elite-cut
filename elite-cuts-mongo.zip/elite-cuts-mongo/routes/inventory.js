const { makeCrudRouter } = require('../middleware/crudFactory');
const InventoryItem = require('../models/InventoryItem');
module.exports = makeCrudRouter(InventoryItem, { publicRead: false });
