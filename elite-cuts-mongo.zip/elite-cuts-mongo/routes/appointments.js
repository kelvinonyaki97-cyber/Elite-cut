const express = require('express');
const router = express.Router();
const { requireAdmin } = require('../middleware/auth');
const Appointment = require('../models/Appointment');

function genRef() {
  return 'ELT-' + String(Math.floor(Math.random() * 9000) + 1000);
}

// GET /api/appointments — admin only (booking data is business-sensitive)
router.get('/', requireAdmin, async (req, res) => {
  try {
    const docs = await Appointment.find().sort({ createdAt: -1 });
    res.json(docs);
  } catch (e) {
    res.status(500).json({ message: 'Could not load appointments.', error: e.message });
  }
});

// POST /api/appointments — public. Anyone booking through the site can create one.
router.post('/', async (req, res) => {
  try {
    const { customer, service, barber, date, time, amount } = req.body;
    if (!customer || !service || !barber) {
      return res.status(400).json({ message: 'customer, service and barber are required.' });
    }
    let ref, exists = true;
    while (exists) {
      ref = genRef();
      exists = await Appointment.exists({ ref });
    }
    const doc = await Appointment.create({
      ref, customer, service, barber,
      date: date || 'TBC', time: time || 'TBC',
      status: 'pending', amount: Number(amount) || 0,
    });
    res.status(201).json(doc);
  } catch (e) {
    res.status(400).json({ message: 'Could not create appointment.', error: e.message });
  }
});

// PUT /api/appointments/:id — admin only (status changes, edits)
router.put('/:id', requireAdmin, async (req, res) => {
  try {
    const doc = await Appointment.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
    if (!doc) return res.status(404).json({ message: 'Not found.' });
    res.json(doc);
  } catch (e) {
    res.status(400).json({ message: 'Could not update appointment.', error: e.message });
  }
});

// DELETE /api/appointments/:id — admin only
router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    const doc = await Appointment.findByIdAndDelete(req.params.id);
    if (!doc) return res.status(404).json({ message: 'Not found.' });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ message: 'Could not delete appointment.', error: e.message });
  }
});

module.exports = router;
