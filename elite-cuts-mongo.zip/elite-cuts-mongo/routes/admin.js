const express = require('express');
const bcrypt = require('bcryptjs');
const router = express.Router();
const { signAdminToken, requireAdmin } = require('../middleware/auth');
const { getOrCreateSettings } = require('../middleware/settingsHelper');

// POST /api/admin/login  { password } -> { token }
router.post('/login', async (req, res) => {
  try {
    const { password } = req.body;
    if (!password) return res.status(400).json({ message: 'Password is required.' });
    const settings = await getOrCreateSettings();
    const ok = await bcrypt.compare(password, settings.adminPasswordHash);
    if (!ok) return res.status(401).json({ message: 'Incorrect password.' });
    const token = signAdminToken();
    res.json({ token });
  } catch (e) {
    res.status(500).json({ message: 'Login failed.', error: e.message });
  }
});

// PUT /api/admin/password  { currentPassword, newPassword } -> { ok:true }  (requires admin token)
router.put('/password', requireAdmin, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    if (!newPassword || newPassword.length < 4) {
      return res.status(400).json({ message: 'New password must be at least 4 characters.' });
    }
    const settings = await getOrCreateSettings();
    const ok = await bcrypt.compare(currentPassword || '', settings.adminPasswordHash);
    if (!ok) return res.status(401).json({ message: 'Current password is incorrect.' });
    settings.adminPasswordHash = await bcrypt.hash(newPassword, 10);
    await settings.save();
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ message: 'Could not update password.', error: e.message });
  }
});

module.exports = router;
