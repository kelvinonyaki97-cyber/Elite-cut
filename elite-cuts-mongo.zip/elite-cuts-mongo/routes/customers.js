const { makeCrudRouter } = require('../middleware/crudFactory');
const Customer = require('../models/Customer');
module.exports = makeCrudRouter(Customer, { publicRead: false });
