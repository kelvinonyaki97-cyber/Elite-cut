const { makeCrudRouter } = require('../middleware/crudFactory');
const Testimonial = require('../models/Testimonial');
module.exports = makeCrudRouter(Testimonial, { publicRead: true });
