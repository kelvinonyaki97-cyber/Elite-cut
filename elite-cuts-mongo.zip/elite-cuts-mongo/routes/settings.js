const express = require('express');
const router = express.Router();
const { requireAdmin } = require('../middleware/auth');
const { getOrCreateSettings } = require('../middleware/settingsHelper');

// Fields the public site is allowed to see. adminPasswordHash is NEVER sent to the client.
function publicShape(settings) {
  const { business, hero, theme, contact, social, loyalty, hours } = settings.toObject();
  return { business, hero, theme, contact, social, loyalty, hours };
}

// GET /api/settings — public, powers the homepage
router.get('/', async (req, res) => {
  try {
    const settings = await getOrCreateSettings();
    res.json(publicShape(settings));
  } catch (e) {
    res.status(500).json({ message: 'Could not load settings.', error: e.message });
  }
});

// PUT /api/settings — admin only. Body may contain any subset of
// { business, hero, theme, contact, social, loyalty, hours }.
router.put('/', requireAdmin, async (req, res) => {
  try {
    const settings = await getOrCreateSettings();
    const allowed = ['business', 'hero', 'theme', 'contact', 'social', 'loyalty', 'hours'];
    for (const key of allowed) {
      if (req.body[key] !== undefined) {
        if (key === 'hours') {
          settings.hours = req.body.hours;
        } else {
          settings[key] = Object.assign({}, settings[key]?.toObject ? settings[key].toObject() : settings[key], req.body[key]);
        }
      }
    }
    await settings.save();
    res.json(publicShape(settings));
  } catch (e) {
    res.status(500).json({ message: 'Could not save settings.', error: e.message });
  }
});

module.exports = router;
